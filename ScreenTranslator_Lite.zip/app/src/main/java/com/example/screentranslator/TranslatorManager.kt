package com.example.screentranslator

object TranslatorManager {
    // Placeholder translator. Replace with real API calls or local model.
    fun translate(source: String, targetLang: String): String {
        return "[翻译占位] $source -> $targetLang"
    }
}
